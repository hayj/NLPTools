
Good news : most shorteners keep same short urls for same urls, here it works on bit.ly and tinyurl.com but not on shorturl.at


89.234.157.254
http://amp.kansascity.com/news/business/national-international/article210807719.html
https://bit.ly/2wHweKd https://bit.ly/2wHweKd
shorturl.at/bluN5 shorturl.at/gmpX5
https://tinyurl.com/y7mqd7m2 https://tinyurl.com/y7mqd7m2



72.52.77.103
http://amp.kansascity.com/news/business/national-international/article210807719.html
https://bit.ly/2wHweKd
shorturl.at/bnOY5
https://tinyurl.com/y7mqd7m2