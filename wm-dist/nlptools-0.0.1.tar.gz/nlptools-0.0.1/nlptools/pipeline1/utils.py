
from enum import Enum

TOKEN_TYPE = Enum("TOKEN_TYPE", "num alpha alphanum price unknown punct1 punct2 atreply hashtag emoji url email none quote currency social function")